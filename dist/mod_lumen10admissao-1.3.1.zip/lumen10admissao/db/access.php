<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * @package mod_lumen10admissao
 * @copyright 2026 Carlos Antonio de Oliveira Piquet
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$capabilities = [
    'mod/lumen10admissao:delete' => ['riskbitmask' => RISK_DATALOSS | RISK_PERSONAL, 'captype' => 'write', 'contextlevel' => CONTEXT_MODULE,
        'archetypes' => ['manager' => CAP_ALLOW]],
    'mod/lumen10admissao:addinstance' => [
        'riskbitmask' => RISK_SPAM, 'captype' => 'write', 'contextlevel' => CONTEXT_COURSE,
        'archetypes' => ['manager' => CAP_ALLOW, 'editingteacher' => CAP_ALLOW],
        'clonepermissionsfrom' => 'moodle/course:manageactivities',
    ],
    'mod/lumen10admissao:view' => [
        'captype' => 'read', 'contextlevel' => CONTEXT_MODULE,
        'archetypes' => ['user' => CAP_ALLOW, 'student' => CAP_ALLOW, 'manager' => CAP_ALLOW, 'editingteacher' => CAP_ALLOW],
    ],
    'mod/lumen10admissao:review' => [
        'riskbitmask' => RISK_PERSONAL, 'captype' => 'read', 'contextlevel' => CONTEXT_MODULE,
        'archetypes' => ['manager' => CAP_ALLOW],
    ],
    'mod/lumen10admissao:approve' => [
        'riskbitmask' => RISK_PERSONAL | RISK_SPAM, 'captype' => 'write', 'contextlevel' => CONTEXT_MODULE,
        'archetypes' => ['manager' => CAP_ALLOW],
    ],
];
