<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * @package mod_lumen10admissao
 * @copyright 2026 Carlos Antonio de Oliveira Piquet
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace mod_lumen10admissao\event;
defined('MOODLE_INTERNAL') || die();
final class application_updated extends \core\event\base {
    protected function init(): void {
        $this->data['crud'] = 'u';
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'lumen10admissao_req';
    }
    public static function get_name(): string { return get_string('eventapplication', 'mod_lumen10admissao'); }
    public function get_description(): string { return "Admission {$this->objectid}: {$this->other['action']} by user {$this->userid}."; }
    public function get_url(): \moodle_url { return new \moodle_url('/mod/lumen10admissao/analisar.php', ['id' => $this->objectid]); }
    public static function get_objectid_mapping(): array { return ['db' => 'lumen10admissao_req', 'restore' => self::NOT_MAPPED]; }
    public static function get_other_mapping(): array { return []; }
}
